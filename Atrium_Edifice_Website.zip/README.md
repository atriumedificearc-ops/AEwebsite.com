# Atrium Edifice Website

A responsive, single-page website concept for Atrium Edifice, Accra, Ghana.

## Files
- `index.html` — website structure and content
- `style.css` — responsive styling
- `script.js` — mobile navigation, current year, and email enquiry form
- `assets/atrium-edifice-logo.jpeg` — your supplied logo image

## Preview locally
1. Extract the ZIP folder.
2. Open `index.html` in a modern browser.
3. Keep an internet connection active for Google Fonts and the remote portfolio reference images.

## Contact form
The form opens the visitor's default email app with a prefilled email to `atriumedifice.arc@gmail.com`. It does not store or submit messages to a server. For a live website, connect a form backend or form service.

## Before publishing
- Replace the sample/reference images with your own project photography and renders.
- Confirm the phone numbers and contact details.
- Add your domain and hosting.
- If you want the form to submit online without opening email, connect a backend or service such as Formspree.
